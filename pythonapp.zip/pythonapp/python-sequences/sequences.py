name = "Alice"
coordinates = (10.0, 20.0) #python tuple()
names = ["Alice", "Bob", "Charles"] #python list()

print(name[2]) #3rd item in name string
print(coordinates[1]) #2nd item in coordinates tuples
print(names[0]) #1st item in names string


#list denoted by square bracket []
#Sequence in python could be string, list, tuples, sequence of numbers or characters etc.
#to access items in a sequence, it uses zero index, meaning to access 'A' in the "names" list(sequence) above
# I could do this names[0]. This is called zero(0) index system. where 1st item is zero, 2nd is 1 etc