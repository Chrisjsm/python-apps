for i in range(10):
    print(i)
#The program above says, print a range of numbers ranging from zero(0)
# upto but not including 5. just loop/print out five numbers, 0 included to make it up to 5 numbers.

names = ["Alice", "Paul", "James", "Chris"]
print(names)
for name in names:
    print(name)

#Note: it's good practice to have each items in a list to be of same types(data-types).It conveys symantic meaning, and
#could also help perform same operations on those items.
#means loop over names variable one at a time and save each values in name variable
#note you don't need the print() statement when running python program in command line bcos the interpreter already knows what to do
#unlike in your python file that you'll need to explicitly specify what to print-out to the screen
