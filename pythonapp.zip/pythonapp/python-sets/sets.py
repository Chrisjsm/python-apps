#sets is a collection of items, whereby no item shows-up twice, items in a set are unique. Repeated items are printed as one(merged)
#it does have any particular order.

s = set() #this is just a function that creates an empty set for me. and below, I'm adding items with add() method to the set "s".
s.add(1)
s.add(3)
s.add(5)
s.add(3)
print(s)