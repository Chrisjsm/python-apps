x = -28

if x > 0:
    print("x is positive")
elif x < 0:
    print("x is negative")
else:
    print("x is zero")

#note indentations in python is very necessary.
#if a condition is true, anything indented under that conditional 
#statement will run.