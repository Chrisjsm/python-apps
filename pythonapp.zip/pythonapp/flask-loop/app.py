from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def index():
    names = ["Chris", "James", "Ogar Chuks", "Oseni", "Dr Sam"]
    return render_template("names.html", names = names )

 
