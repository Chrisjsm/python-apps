i = 28  #type int
print(f"i is {i}")

f = 2.8 #type float
print(f"i is {f}")

b = True    #type bool
print(f"b is {b}")

n = None    #type None
print(f"n is {n}")