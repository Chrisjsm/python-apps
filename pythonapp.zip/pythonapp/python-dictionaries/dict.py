#python dictionaries are used to map certain values to other values in key:value pairs. It's another type in python.
#dict() method can also be used to create a dictionary in python. note the double brackets "(())"
''' #errors to be checked back.
#men = dict(("king":"Romans", "Queen":"Nigerian", "Governor":"Akwa-Ibom State"))
men = dict("Alice":22, "Bob":27, "Charles":22)
print(men)
'''
ages = {"Alice":22, "Bob":27, "Charles":22}
ages["Bob"] = 30    #updating the value of "Bob"
ages["James"] = 18    #Adding new item(key:value) to the dictionary
ages["Alice"] += 2  #Incrementing the value of "Alice"

print(ages)
