from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def index():
    return "Hello, World"
    #print("flask application")


@app.route("/chris")
def chris():
    return "Hello, Chris"


@app.route("/james")
def james():
    return "Hello James"

#making our flask dynamic, now it's able to take any string typed-in and return hello based on the what was typed-in
#using the <string:name>
@app.route("/<string:name>")
def hello(name):
    name = name.capitalize()
    return f"<h1> Hello, {name}</h1>"




 
