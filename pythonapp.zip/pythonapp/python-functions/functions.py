 #defining a function square(x) taking an argument (x) 
#the for loop below with the .format() method is what is saying that whatever is 'i' plg it in the 1st placeholder and whatever is the 
#value of 'square(i)' plug it into the 2nd placeholder in the print statement.

def square(x):
    return x * x

for i in range(10):
    print("{} squared is {}".format(i, square(i)))